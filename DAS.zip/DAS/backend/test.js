db.Appointments.renameCollection("appointments")
