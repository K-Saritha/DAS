

const express = require("express");
const connectDB = require("./src/config/database");
const cors = require("cors");
require("dotenv").config();

// Import Models
const Appointment = require("./src/models/Appointments");

// Import Routes
const patientRoutes = require("./src/routes/patientRoutes");
const adminRoutes=require("./src/routes/Adminroutes");
const expressListEndpoints = require("express-list-endpoints");

const app = express();
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ API Overview
app.get("/api", (req, res) => {
  const endpoints = expressListEndpoints(app);
  res.json(endpoints);
});

// ✅ Home Route
app.get("/", (req, res) => {
  res.send("Doctor Appointment System API is running...");
});

// ✅ Appointment Routes
app.get("/api/appointments", async (req, res) => {
  try {
    const appointments = await Appointment.find();
    if (!appointments.length) {
      return res.status(404).json({ error: "No appointments found" });
    }
    res.json(appointments);
  } catch (error) {
    console.error("Error fetching appointments:", error);
    res.status(500).json({ error: "Failed to fetch appointments" });
  }
});

// ✅ Get Appointments by Patient ID
app.get("/api/appointments/:patientId", async (req, res) => {
  try {
    const { patientId } = req.params;
    console.log(`🔍 Fetching appointments for patient_id: ${patientId}`);

    const appointments = await Appointment.find({ patient_id: patientId });
    if (!appointments.length) {
      return res.status(404).json({ message: "No appointments found for this patient" });
    }

    console.log("📌 Found Appointments:", appointments);
    res.json(appointments);
  } catch (error) {
    console.error("❌ Error fetching appointments:", error);
    res.status(500).json({ message: "Error fetching appointments", error });
  }
});

// ✅ Patient Routes
app.use("/api/patients", patientRoutes);
app.use("/api/admin",adminRoutes)

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
