import React, { useState, useEffect } from 'react';
import { FaHome, FaUserMd, FaPlus, FaTrash } from 'react-icons/fa';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [newDoctor, setNewDoctor] = useState({ name: '', specialty: '' });

  useEffect(() => {
    fetch("http://localhost:5000/api/appointments")
      .then((res) => res.json())
      .then((data) => {
        console.log("Appointments Data:", data); // Debugging
        setAppointments(data);
      })
      .catch((error) => console.error("Error fetching appointments:", error));
  
    fetch("http://localhost:5000/api/doctors")
      .then((res) => res.json())
      .then((data) => {
        console.log("Doctors Data:", data); // Debugging
        setDoctors(data);
      })
      .catch((error) => console.error("Error fetching doctors:", error));
  }, []);
  
  // Handle adding a new doctor
  const handleAddDoctor = () => {
    if (!newDoctor.name || !newDoctor.specialty) return alert('Fill all fields');
    setDoctors([...doctors, { id: Date.now(), ...newDoctor }]);
    setNewDoctor({ name: '', specialty: '' });
  };

  // Handle removing a doctor
  const handleRemoveDoctor = (id) => {
    setDoctors(doctors.filter(doctor => doctor.id !== id));
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-900 text-white flex flex-col p-5">
        <h1 className="text-2xl font-bold mb-8">Admin Panel</h1>
        <button className={`flex items-center gap-2 p-3 mb-4 rounded-lg transition ${activeTab === 'home' ? 'bg-blue-700' : ''}`} onClick={() => setActiveTab('home')}>
          <FaHome /> Home
        </button>
        <button className={`flex items-center gap-2 p-3 rounded-lg transition ${activeTab === 'doctors' ? 'bg-blue-700' : ''}`} onClick={() => setActiveTab('doctors')}>
          <FaUserMd /> Doctors
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6">
        {/* Home Tab - Scheduled Appointments */}
        {activeTab === 'home' && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Scheduled Appointments</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {appointments.map(appt => (
                <div key={appt.id} className="p-4 bg-white rounded-lg shadow">
                  <h3 className="font-semibold">{appt.patient}</h3>
                  <p className="text-gray-600">Time: {appt.time}</p>
                  <p className="text-gray-600">Doctor: {appt.doctor}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Doctors Tab - Manage Doctors */}
        {activeTab === 'doctors' && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Doctors List</h2>

            {/* Add Doctor Form */}
            <div className="flex gap-4 mb-6">
              <input
                type="text"
                placeholder="Doctor's Name"
                value={newDoctor.name}
                onChange={(e) => setNewDoctor({ ...newDoctor, name: e.target.value })}
                className="p-2 border rounded w-1/3"
              />
              <input
                type="text"
                placeholder="Specialty"
                value={newDoctor.specialty}
                onChange={(e) => setNewDoctor({ ...newDoctor, specialty: e.target.value })}
                className="p-2 border rounded w-1/3"
              />
              <button onClick={handleAddDoctor} className="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2">
                <FaPlus /> Add Doctor
              </button>
            </div>

            {/* Doctors List */}
            <table className="w-full bg-white rounded-lg shadow">
              <thead>
                <tr className="bg-blue-600 text-white">
                  <th className="p-3">Name</th>
                  <th className="p-3">Specialty</th>
                  <th className="p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {doctors.map(doctor => (
                  <tr key={doctor.id} className="border-b">
                    <td className="p-3">{doctor.name}</td>
                    <td className="p-3">{doctor.specialty}</td>
                    <td className="p-3">
                      <button onClick={() => handleRemoveDoctor(doctor.id)} className="bg-red-600 text-white px-3 py-1 rounded flex items-center gap-1">
                        <FaTrash /> Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
